
 <?php $this->beginContent('//layouts/admin_homepage'); ?>
    <?php  echo $content;?>

<?php $this->endContent(); ?>