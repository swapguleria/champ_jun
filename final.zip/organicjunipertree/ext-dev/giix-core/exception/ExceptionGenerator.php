<?php
/**
 * Exception Generator.
 *
 * @author Stefan Volkmar <volkmar_yii@email.de>
 * @link http://www.yiiframework.com/extension/yii-generator-collection/
 * @license BSD
 */
class ExceptionGenerator extends CCodeGenerator
{
    public $codeModel='ext-dev.giix-core.exception.ExceptionCode';

}
?>
