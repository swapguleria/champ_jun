<?php echo "<?php\n"; ?>
/**
 * <?php echo ucfirst($this->className).'Application'; ?> class file.
 */

class <?php echo ucfirst($this->className).'Application'; ?> extends <?php echo $this->baseClass."\n"; ?>
{
	/**
	 * Processes the request.
	 * This is the place where the actual request processing work is done.
	 */
	public function processRequest()
    {
        // your code here...
    }

}
