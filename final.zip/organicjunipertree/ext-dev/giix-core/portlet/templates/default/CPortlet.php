<?php echo "<?php\n"; ?>
/**
 * <?php echo ucfirst($this->className)."Portlet"; ?> class file.
 */
 
class <?php echo ucfirst($this->className)."Portlet"; ?> extends <?php echo $this->baseClass."\n"; ?>
{
	/**
	 * Renders the content of the portlet.
	 */
	protected function renderContent()
	{
	}
}