<p style="padding:5px;">A portlet displays a fragment of content with a title, usually in terms of a block
 on the side bars of a Web page.
 </p>
