<p style="padding:5px;">
A filter can be applied before and after an action is executed. 
It can modify the data that the action is to run or decorate the result 
that the action generates.
</p>