<div style="padding:5px;">
This generator is for different caching classes.<br />Derive your caching classes from:
<ul style="margin-top:8px">
<li>CCache</li>
<li>CCacheDependency</li>
</ul>
</div>
<div style="padding:5px;">
You can find a list of public caching classes here:
<ul style="margin-top:8px">
<li><a href="http://www.yiiframework.com/doc/api/" target="_blank">Yii Class Reference</a></li>
<li><a href="http://www.yiiframework.com/extensions/?category=2" target="_blank">Yii Extension Repository</a></li>
</ul>
</div>