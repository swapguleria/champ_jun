<p style="padding:5px;">
CAction provides a way to divide a complex controller into
smaller actions in separate class files. (<a href="http://www.yiiframework.com/doc/guide/basics.controller" target="_blank">more...</a>)
</p>
<div style="padding:5px;">
See also here:
<ul style="margin-top:8px">
<li><a href="http://www.yiiframework.com/extension/render-action/" target="_blank">Class XRenderAction</a></li>
<li><a href="http://www.yiiframework.com/wiki/170/actions-code-reuse-with-caction/" target="_blank">Yii-Wiki: Actions code reuse with CAction</a></li>
</ul>
</div>