<?php echo "<?php\n"; ?>
/**
 * <?php echo ucfirst($this->className); ?> class file. 
 */

class <?php echo ucfirst($this->className); ?> extends <?php echo $this->baseClass."\n"; ?>
{

}
