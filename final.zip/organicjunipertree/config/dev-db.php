<?php
return array(
		'connectionString' => 'mysql:host=127.0.0.1;dbname=dextero3_organicjunipertree',
		'emulatePrepare' => true,
		'username' => 'dextero3_organic',
		'password' => 'organic',
		'charset' => 'utf8',
		'tablePrefix' => 'tbl_',
		'schemaCachingDuration' => (60 * 60 * 24),
		'queryCachingDuration'=> (60 * 60 * 24) ,
);
