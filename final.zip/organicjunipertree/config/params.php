<?php

// this contains the application parameters that can be maintained via GUI
return array(
    // this is used in error pages
    'adminEmail' => 'swap.guleria@gmail.com',
    'company' => 'Organic Juniper Tree',
    'languages' => array(
        'en' => 'en.png',
        'ar' => 'ar.jpg'
    )
        )
;
