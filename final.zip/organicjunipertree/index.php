<?php


//exit();

require (dirname(__FILE__).'/common.php');

require_once($yii);
Yii::createWebApplication($config)->run();?>